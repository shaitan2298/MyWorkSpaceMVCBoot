package com.cg.banking.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;

@Controller
public class BankingServicesController {
	@Autowired
	BankingServices services;

	@RequestMapping("/registerAccount")
	public ModelAndView getRegisterAccount( @ModelAttribute Account account)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServiceDownException {
		account = services.openAccount(account);
		return new ModelAndView("openAccountSuccess", "account", account);
	}
	
	 @RequestMapping("/depositAmount") 
	  public ModelAndView getDepositAmount(@RequestParam("account.accountNo") long accountNo, @RequestParam float amount) throws AccountNotFoundException,
	  BankingServiceDownException, AccountBlockedException 
	  { 
		  float account = services.depositAmount(accountNo,amount); 
		  return new  ModelAndView("depositAmountSuccess","account",account);
	  }
	 @RequestMapping("/withdrawAmount") 
	  public ModelAndView getWithdrawAmount(@RequestParam("account.accountNo") long accountNo, @RequestParam float amount,@RequestParam ("account.pinNumber") long pinNumber) throws AccountNotFoundException,
	  BankingServiceDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException 
	  { 
		  float account = services.withdrawAmount(accountNo,amount,pinNumber); 
		  return new  ModelAndView("withdrawAmountSuccess","account",account);
	  }
	 @RequestMapping("/fundTransfer") 
	  public ModelAndView getFundTransferAmount(@RequestParam("account.accountNo") long accountNoTo, @RequestParam("account.accountNo") long accountNoFrom,@RequestParam float amount,@RequestParam ("account.pinNumber") long pinNumber) throws AccountNotFoundException,
	  BankingServiceDownException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException 
	  { 
		  float account = services.fundTransfer(accountNoTo,accountNoFrom,amount,pinNumber); 
		  return new  ModelAndView("fundTransferSuccess","account",account);
	  }
}
