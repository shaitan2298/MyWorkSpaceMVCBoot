package com.cg.billing.daoservices;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

public interface PostpaidAccountDAO extends JpaRepository<PostpaidAccount, Long>
{
	@Query("SELECT p from PostpaidAccount p where p.customer.customerId=:customerId")
	 List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(@Param("customerId") int customerID) throws CustomerDetailsNotFoundException;
	
	@Transactional
	@Modifying
	@Query("DELETE from PostpaidAccount d where d.mobileNo = ?1")
	public int closeCustomerPostpaidAccount(long mobileNo) throws PostpaidAccountNotFoundException;
	 
}
